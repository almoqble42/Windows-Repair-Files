#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <commdlg.h>
#include <string>
#include <vector>
#include <process.h>

#ifndef WC_TABCONTROL
#define WC_TABCONTROL L"SysTabControl32"
#endif

static HINSTANCE g_inst;
static HWND g_hMain, g_hTab, g_hLog, g_hStatus, g_hDry, g_hMin, g_hExit, g_hLangAr, g_hLangEn, g_hSaveLog;
static HWND g_hTip = NULL;
static HFONT g_font, g_logFont;
static const wchar_t* kBatPath = L"C:\\Repair\\repair.bat";
static bool g_busy = false;
static bool g_exiting = false;
static HANDLE g_hChild = NULL;
static HANDLE g_hWorker = NULL;
static HANDLE g_hJob = NULL;
static DWORD  g_childPid = 0;
static std::wstring g_curIn, g_curOut;
static int g_winW = 1000, g_winH = 680, g_selTab = 0;

#define TIMER_TIP 7701
#define TIMER_TIP_HIDE 9102
#define TIP_DELAY_MS 500
#define TIP_HIDE_MS 500
#define TIP_TRACK_ID 9999
#define IDC_TIP_TRACK 9999

struct TipEntry { HWND h; std::wstring text; };
static std::vector<TipEntry> g_tips;
static HWND g_lastFocus = NULL;
static HWND g_pendingCtrl = NULL;
static std::wstring g_pendingText;
static std::wstring g_trackTip;
static std::vector<HWND> g_kbShown;
static HWND g_pages[8];
static int g_lastFocusRoot = -3;
static int g_lastFocusId = 0;
static int g_lastMouseX = -1, g_lastMouseY = -1;

static bool g_english = false;
static inline const wchar_t* TR(const wchar_t* ar, const wchar_t* en) {
    return g_english ? en : ar;
}
static inline bool Rtl() { return !g_english; }

static std::wstring SettingsPath() {
    wchar_t ap[MAX_PATH];
    DWORD n = GetEnvironmentVariableW(L"APPDATA", ap, MAX_PATH);
    if (n > 0 && n < MAX_PATH) {
        std::wstring dir = std::wstring(ap) + L"\\RepairToolkit";
        CreateDirectoryW(dir.c_str(), NULL);
        return dir + L"\\RepairUI.ini";
    }
    wchar_t exe[MAX_PATH];
    GetModuleFileNameW(NULL, exe, MAX_PATH);
    std::wstring p = exe;
    size_t s = p.find_last_of(L"\\/");
    if (s != std::wstring::npos) p.resize(s);
    return p + L"\\RepairUI.ini";
}

static void LoadSettings() {
    std::wstring p = SettingsPath();
    g_english = GetPrivateProfileIntW(L"UI", L"English", 0, p.c_str()) != 0;
    g_winW = (int)GetPrivateProfileIntW(L"UI", L"WinW", 1000, p.c_str());
    g_winH = (int)GetPrivateProfileIntW(L"UI", L"WinH", 680, p.c_str());
    g_selTab = 0;
    g_lastFocusRoot = (int)GetPrivateProfileIntW(L"UI", L"FocusRoot", -3, p.c_str());
    g_lastFocusId = (int)GetPrivateProfileIntW(L"UI", L"FocusId", 0, p.c_str());
    g_lastMouseX = (int)GetPrivateProfileIntW(L"UI", L"MouseX", -1, p.c_str());
    g_lastMouseY = (int)GetPrivateProfileIntW(L"UI", L"MouseY", -1, p.c_str());
    if (g_winW < 960) g_winW = 960;
    if (g_winH < 600) g_winH = 600;
    if (g_selTab < 0 || g_selTab > 7) g_selTab = 0;
}

static void SaveSettings() {
    std::wstring p = SettingsPath();
    WritePrivateProfileStringW(L"UI", L"English", g_english ? L"1" : L"0", p.c_str());
    WritePrivateProfileStringW(L"UI", L"WinW", std::to_wstring(g_winW).c_str(), p.c_str());
    WritePrivateProfileStringW(L"UI", L"WinH", std::to_wstring(g_winH).c_str(), p.c_str());
    WritePrivateProfileStringW(L"UI", L"Tab", NULL, p.c_str());
    WritePrivateProfileStringW(L"UI", L"FocusRoot", NULL, p.c_str());
    WritePrivateProfileStringW(L"UI", L"FocusId", NULL, p.c_str());
    WritePrivateProfileStringW(L"UI", L"MouseX", NULL, p.c_str());
    WritePrivateProfileStringW(L"UI", L"MouseY", NULL, p.c_str());
}

static void ArmTip(HWND ctrl, const std::wstring& text);

static const wchar_t* g_tabTipsAr[8] = {
    L"إصلاح النظام - إصلاحات أساسية شاملة",
    L"التنظيف - إزالة الملفات المؤقتة وذاكرة التخزين المؤقت",
    L"الفحص - فحوصات التشخيص وسلامة النظام",
    L"الصيانة - مهام دورية وتحديث المكونات",
    L"التقارير - عرض وتصدير تقارير الفحص",
    L"الأدوات - أدوات مساعدة وجولات متكاملة",
    L"السجل - سجل تنفيذ كل العمليات",
    L"الإعدادات - خيارات التشغيل العامة"
};
static const wchar_t* g_tabTipsEn[8] = {
    L"System Repair - comprehensive basic repairs",
    L"Cleanup - remove temporary files and caches",
    L"Check - diagnostics and system health scans",
    L"Maintenance - routine tasks and component updates",
    L"Reports - view and export scan reports",
    L"Tools - helper utilities and integrated runs",
    L"Log - record of all operations",
    L"Settings - general run options"
};
static inline const wchar_t* TabTip(int i) {
    return g_english ? g_tabTipsEn[i] : g_tabTipsAr[i];
}

#define WM_RUN_DONE (WM_APP + 1)
#define WM_TIP_DONE (WM_APP + 2)
#define ID_LOG 1100
#define ID_DRY 9500
#define ID_MINIMIZE 9100
#define ID_EXIT 9101
#define ID_LANG_AR 9600
#define ID_LANG_EN 9601
#define ID_SAVELOG 9603

static void BuildPage(int idx);
static void ShowTab(int idx);
static HWND FirstFocusable(HWND parent);

static void LogAppend(const std::wstring& msg) {
    if (!g_hLog) return;
    int len = GetWindowTextLengthW(g_hLog);
    SendMessageW(g_hLog, EM_SETSEL, (WPARAM)len, (LPARAM)len);
    std::wstring s = msg + L"\r\n\r\n";
    SendMessageW(g_hLog, EM_REPLACESEL, FALSE, (LPARAM)s.c_str());
}

static void SetStatus(const std::wstring& s) {
    if (g_hStatus) SetWindowTextW(g_hStatus, s.c_str());
}

static void AddToolTip(HWND hwnd, const std::wstring& tip) {
    if (!g_hTip || !hwnd || tip.empty()) return;
    TOOLINFOW ti = { sizeof(ti) };
    ti.uFlags = TTF_IDISHWND | TTF_SUBCLASS | TTF_TRANSPARENT;
    ti.hwnd = GetParent(hwnd) ? GetParent(hwnd) : g_hMain;
    ti.uId = (UINT_PTR)hwnd;
    ti.lpszText = LPSTR_TEXTCALLBACKW;
    SendMessageW(g_hTip, TTM_ADDTOOLW, 0, (LPARAM)&ti);
    SendMessageW(g_hTip, TTM_ACTIVATE, TRUE, 0);
    g_tips.push_back(TipEntry{ hwnd, tip });
}

// Mouse balloons are shown only once per element: after the first pop the tool
// is removed so hovering no longer re-triggers it. A right-click re-shows it.
static void RemoveTipTool(HWND ctrl) {
    if (!g_hTip || !ctrl) return;
    // Do not touch the track tool (uId == TIP_TRACK_ID) used for keyboard balloons
    if ((UINT_PTR)ctrl == TIP_TRACK_ID) return;
    TOOLINFOW ti = { sizeof(ti) };
    ti.uFlags = TTF_IDISHWND;
    HWND ph = GetParent(ctrl);
    ti.hwnd = ph ? ph : g_hMain;
    ti.uId = (UINT_PTR)ctrl;
    SendMessageW(g_hTip, TTM_DELTOOLW, 0, (LPARAM)&ti);
}

static std::wstring TipTextFor(HWND h) {
    for (size_t i = 0; i < g_tips.size(); ++i)
        if (g_tips[i].h == h) return g_tips[i].text;
    return std::wstring();
}

static std::wstring TipFor(HWND h) {
    if (h == g_hTab) {
        int cur = TabCtrl_GetCurSel(g_hTab);
        if (cur >= 0 && cur < 8) return TR(g_tabTipsAr[cur], g_tabTipsEn[cur]);
    }
    return TipTextFor(h);
}

static void HideKeyboardTip() {
    if (!g_hTip) return;
    TOOLINFOW ti = { sizeof(ti) };
    ti.hwnd = g_hMain;
    ti.uId = TIP_TRACK_ID;
    ti.uFlags = TTF_TRACK | TTF_ABSOLUTE;
    SendMessageW(g_hTip, TTM_TRACKACTIVATE, FALSE, (LPARAM)&ti);
    ShowWindow(g_hTip, SW_HIDE);
}

static void ShowKeyboardTip(HWND ctrl, const std::wstring& text) {
    if (!g_hTip || !ctrl || text.empty()) return;
    g_trackTip = text;
    TOOLINFOW ti = { sizeof(ti) };
    ti.hwnd = g_hMain;
    ti.uId = TIP_TRACK_ID;
    ti.uFlags = TTF_TRACK | TTF_ABSOLUTE;
    ti.lpszText = (LPWSTR)g_trackTip.c_str();
    SendMessageW(g_hTip, TTM_SETTOOLINFOW, 0, (LPARAM)&ti);
    RECT rc;
    if (GetWindowRect(ctrl, &rc)) {
        SendMessageW(g_hTip, TTM_TRACKPOSITION, 0, (LPARAM)MAKELONG(rc.left, rc.bottom));
    }
    SendMessageW(g_hTip, TTM_TRACKACTIVATE, TRUE, (LPARAM)&ti);
    SendMessageW(g_hTip, TTM_POPUP, 0, 0);
    SetTimer(g_hMain, TIMER_TIP_HIDE, TIP_HIDE_MS, NULL);
}

static bool KbTipShown(HWND c) {
    for (size_t i = 0; i < g_kbShown.size(); ++i)
        if (g_kbShown[i] == c) return true;
    return false;
}

static void MarkKbTipShown(HWND c) {
    if (c && !KbTipShown(c)) g_kbShown.push_back(c);
}

static void ClearKbTipShown(HWND c) {
    for (size_t i = 0; i < g_kbShown.size(); ++i) {
        if (g_kbShown[i] == c) { g_kbShown.erase(g_kbShown.begin() + (int)i); break; }
    }
}

static void ArmTip(HWND ctrl, const std::wstring& text) {
    HideKeyboardTip();
    KillTimer(g_hMain, TIMER_TIP_HIDE);
    KillTimer(g_hMain, TIMER_TIP);
    g_pendingCtrl = NULL;
    g_pendingText.clear();
    if (ctrl && !text.empty() && !KbTipShown(ctrl)) {
        g_pendingCtrl = ctrl;
        g_pendingText = text;
        SetTimer(g_hMain, TIMER_TIP, TIP_DELAY_MS, NULL);
    }
}



static bool ShiftDown() {
    return (GetKeyState(VK_SHIFT) & 0x8000) != 0;
}

static bool HandleTabKey(int vk) {
    int n = TabCtrl_GetItemCount(g_hTab);
    if (n <= 0) return false;
    if (vk == VK_RETURN || vk == VK_SPACE ||
        (vk == VK_TAB && !ShiftDown())) {
        int cur = TabCtrl_GetCurSel(g_hTab);
        if (cur >= 0 && cur < 8 && g_pages[cur]) {
            HWND first = FirstFocusable(g_pages[cur]);
            if (!first) {
                LONG st = GetWindowLongW(g_pages[cur], GWL_STYLE);
                if ((st & WS_TABSTOP) && IsWindowVisible(g_pages[cur]) && IsWindowEnabled(g_pages[cur]))
                    first = g_pages[cur];
            }
            if (first) SetFocus(first);
        }
        return true;
    }
    int cur = TabCtrl_GetCurSel(g_hTab);
    if (cur < 0) cur = 0;
    bool rtl = Rtl();
    int nxt = cur;
    switch (vk) {
        case VK_UP:
            nxt = (cur > 0) ? cur - 1 : cur; break;
        case VK_DOWN:
            nxt = (cur < n - 1) ? cur + 1 : cur; break;
        case VK_LEFT:
            nxt = rtl ? ((cur < n - 1) ? cur + 1 : cur) : ((cur > 0) ? cur - 1 : cur); break;
        case VK_RIGHT:
            nxt = rtl ? ((cur > 0) ? cur - 1 : cur) : ((cur < n - 1) ? cur + 1 : cur); break;
        case VK_HOME:
            nxt = 0; break;
        case VK_END:
            nxt = n - 1; break;
        default:
            return false;
    }
    if (nxt != cur) {
        TabCtrl_SetCurSel(g_hTab, nxt);
        BuildPage(nxt);
        ShowTab(nxt);
    }
    if (nxt >= 0 && nxt < 8) ArmTip(g_hTab, TR(g_tabTipsAr[nxt], g_tabTipsEn[nxt]));
    return true;
}

static std::wstring A2Wcp(const std::string& a, UINT cp) {
    if (a.empty()) return std::wstring();
    int n = MultiByteToWideChar(cp, 0, a.c_str(), (int)a.size(), NULL, 0);
    if (n <= 0) return std::wstring();
    std::wstring w(n, 0);
    MultiByteToWideChar(cp, 0, a.c_str(), (int)a.size(), &w[0], n);
    return w;
}

static std::wstring UTF16Decode(const std::string& d, bool bigEndian) {
    std::wstring w;
    w.reserve(d.size() / 2);
    for (size_t i = 0; i + 1 < d.size(); i += 2) {
        unsigned char a = (unsigned char)d[i], b = (unsigned char)d[i + 1];
        w.push_back(bigEndian ? (wchar_t)((a << 8) | b) : (wchar_t)((b << 8) | a));
    }
    return w;
}

// Decodes one line: strict UTF-8 when it holds valid multi-byte sequences,
// otherwise falls back to the console codepage (cp1256) used by repair.bat.
static std::wstring DecodeLine(const std::string& line) {
    bool hasHigh = false;
    for (size_t i = 0; i < line.size(); ++i)
        if ((unsigned char)line[i] >= 0x80) { hasHigh = true; break; }
    if (hasHigh) {
        int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, line.data(), (int)line.size(), NULL, 0);
        if (n > 0) {
            std::wstring w(n, 0);
            MultiByteToWideChar(CP_UTF8, 0, line.data(), (int)line.size(), &w[0], n);
            return w;
        }
    }
    return A2Wcp(line, 1256);
}

// Detects UTF-8/UTF-16 BOMs, then decodes the rest line by line so that
// cp1256 output from repair.bat and UTF-8 output from sub-tools can coexist.
static std::wstring DecodeOutput(const std::string& data) {
    if (data.size() >= 3 && (unsigned char)data[0] == 0xEF &&
        (unsigned char)data[1] == 0xBB && (unsigned char)data[2] == 0xBF)
        return A2Wcp(data.substr(3), CP_UTF8);
    if (data.size() >= 2 && (unsigned char)data[0] == 0xFF && (unsigned char)data[1] == 0xFE)
        return UTF16Decode(data.substr(2), false);
    if (data.size() >= 2 && (unsigned char)data[0] == 0xFE && (unsigned char)data[1] == 0xFF)
        return UTF16Decode(data.substr(2), true);

    std::wstring out;
    size_t i = 0;
    while (i < data.size()) {
        size_t j = data.find('\n', i);
        if (j == std::string::npos) j = data.size();
        out += DecodeLine(data.substr(i, j - i));
        if (j < data.size()) out += L'\n';
        i = j + 1;
    }
    return out;
}

static std::string ReadAllBytes(const std::wstring& path) {
    std::string data;
    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL,
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return data;
    char tmp[8192];
    DWORD rd;
    while (ReadFile(h, tmp, sizeof(tmp), &rd, NULL) && rd > 0)
        data.append(tmp, rd);
    CloseHandle(h);
    return data;
}

struct RunJob {
    HANDLE hProc;
    std::wstring inPath;
    std::wstring outPath;
    std::wstring label;
};

static unsigned __stdcall WaitThread(void* p) {
    RunJob* j = (RunJob*)p;
    DWORD exitCode = (DWORD)-1;
    if (j->hProc) {
        WaitForSingleObject(j->hProc, INFINITE);
        GetExitCodeProcess(j->hProc, &exitCode);
    }
    std::wstring body = DecodeOutput(ReadAllBytes(j->outPath));
    DeleteFileW(j->inPath.c_str());
    DeleteFileW(j->outPath.c_str());
    std::wstring* result = new std::wstring();
    *result = L"[repair.bat " + j->label + L"]\r\n" + body +
        L"\r\n(exit=" + std::to_wstring((long long)exitCode) + L")";
    PostMessageW(g_hMain, WM_RUN_DONE, (WPARAM)result, 0);
    delete j;
    return 0;
}

static void StartRun(const std::wstring& args, const std::string& input) {
    if (g_busy) { LogAppend(TR(L"* انتظر انتهاء العملية الحالية أو أعد فتح البرنامج.",
                               L"* Wait for the current operation to finish or reopen the program.")); return; }
    g_busy = true;
    std::wstring label = args.empty() ? L"(interactive)" : args;
    SetStatus(TR(L"جارٍ التنفيذ...", L"Running..."));
    LogAppend(std::wstring(L">>> repair.bat ") + label + L"\r\n" +
              TR(L"(رفع الصلاحيات...)", L"(requesting elevation...)"));

    wchar_t tmpDir[32768] = { 0 };
    GetTempPathW(32768, tmpDir);
    DWORD tick = GetTickCount();
    std::wstring inPath = std::wstring(tmpDir) + L"repair_in_" +
        std::to_wstring(GetCurrentProcessId()) + L"_" + std::to_wstring(tick) + L".txt";
    std::wstring outPath = std::wstring(tmpDir) + L"repair_out_" +
        std::to_wstring(GetCurrentProcessId()) + L"_" + std::to_wstring(tick) + L".txt";

    HANDLE hIn = CreateFileW(inPath.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
        FILE_ATTRIBUTE_TEMPORARY, NULL);
    if (hIn != INVALID_HANDLE_VALUE) {
        DWORD wr = 0;
        if (!input.empty())
            WriteFile(hIn, input.c_str(), (DWORD)input.size(), &wr, NULL);
        CloseHandle(hIn);
    }
    DeleteFileW(outPath.c_str());
    g_curIn = inPath;
    g_curOut = outPath;

    std::wstring inner = L"\"" + std::wstring(kBatPath) + L"\"";
    if (!args.empty()) inner += L" " + args;
    std::wstring params = L"/c \"" + inner + L" < \"" + inPath +
        L"\" > \"" + outPath + L"\" 2>&1\"";

    wchar_t winDir[MAX_PATH] = { 0 };
    GetWindowsDirectoryW(winDir, MAX_PATH);
    std::wstring cmdExe = std::wstring(winDir) + L"\\System32\\cmd.exe";

    SHELLEXECUTEINFOW sei = { sizeof(sei) };
    sei.fMask = SEE_MASK_NOCLOSEPROCESS;
    sei.lpVerb = L"runas";
    sei.lpFile = cmdExe.c_str();
    sei.lpParameters = params.c_str();
    sei.nShow = SW_HIDE;

    PVOID oldRedir = NULL;
    BOOL hadRedir = Wow64DisableWow64FsRedirection(&oldRedir);
    BOOL launched = ShellExecuteExW(&sei);
    if (hadRedir) Wow64RevertWow64FsRedirection(oldRedir);

    if (!launched || !sei.hProcess) {
        DWORD err = GetLastError();
        DeleteFileW(inPath.c_str());
        DeleteFileW(outPath.c_str());
        g_busy = false;
        SetStatus(TR(L"جاهز", L"Ready"));
        LogAppend(std::wstring(TR(L"(تعذّر رفع الصلاحيات أو بدء العملية. رمز الخطأ=",
                                  L"(Failed to elevate or start the operation. Error code=")) +
            std::to_wstring((long long)err) + L")");
        return;
    }

    g_hChild = sei.hProcess;
    g_childPid = GetProcessId(sei.hProcess);
    if (!g_hJob) {
        g_hJob = CreateJobObjectW(NULL, NULL);
        if (g_hJob) {
            JOBOBJECT_EXTENDED_LIMIT_INFORMATION jeli = { 0 };
            jeli.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
            SetInformationJobObject(g_hJob, JobObjectExtendedLimitInformation, &jeli, sizeof(jeli));
        }
    }
    if (g_hJob) AssignProcessToJobObject(g_hJob, sei.hProcess);

    RunJob* j = new RunJob();
    j->hProc = sei.hProcess;
    j->inPath = inPath;
    j->outPath = outPath;
    j->label = label;
    g_hWorker = (HANDLE)_beginthreadex(NULL, 0, WaitThread, j, 0, NULL);
    if (!g_hWorker) {
        delete j;
        if (g_hJob) TerminateJobObject(g_hJob, 1);
        if (g_hChild) { TerminateProcess(g_hChild, 1); CloseHandle(g_hChild); g_hChild = NULL; }
        g_childPid = 0;
        DeleteFileW(inPath.c_str());
        DeleteFileW(outPath.c_str());
        g_curIn.clear();
        g_curOut.clear();
        g_busy = false;
        SetStatus(TR(L"جاهز", L"Ready"));
        LogAppend(TR(L"(تعذّر بدء خيط الانتظار. أعد المحاولة.)",
                     L"(Failed to start the wait thread. Please retry.)"));
    }
}

// group: 1..6 => interactive submenu selection; 0 => direct arg in `direct`.
struct BtnDef {
    int id;
    const wchar_t* text;
    const wchar_t* en;
    int group;
    int section;
    const wchar_t* direct;
    bool confirm;
    const char* yesIn;
};

static bool DryRunEnabled() {
    return g_hDry && (SendMessageW(g_hDry, BM_GETCHECK, 0, 0) == BST_CHECKED);
}

// repair.bat only prompts to install PowerShell 7 when pwsh is absent (section 43).
static bool PwshInstalled() {
    wchar_t buf[MAX_PATH];
    return SearchPathW(NULL, L"pwsh.exe", NULL, MAX_PATH, buf, NULL) > 0;
}

static void RunSection(int group, int section, const char* yesIn = NULL) {
    std::wstring args = DryRunEnabled() ? L"/dry-run" : L"";
    std::string input = std::to_string(group) + "\r\n" + std::to_string(section) + "\r\n";
    if (yesIn) input += yesIn;
    else input += "N\r\nN\r\n";
    StartRun(args, input);
}

static void RunDirect(const wchar_t* arg) {
    StartRun(arg, std::string("N\r\nN\r\n"));
}

// ---------------- tab buttons ----------------
static const BtnDef kRepair[] = {
    {101,L"فحص سريع [1]",L"Quick scan [1]",1,1,NULL},
    {102,L"إصلاح كامل [2]",L"Full repair [2]",1,2,NULL},
    {103,L"إصلاح + تنظيف [3]",L"Repair + cleanup [3]",1,3,NULL},
    {105,L"إصلاح الشبكة [5]",L"Network repair [5]",1,5,NULL},
    {106,L"Windows Update [6]",L"Windows Update [6]",1,6,NULL},
    {107,L"تسجيل DLL [7]",L"Register DLLs [7]",1,7,NULL},
    {108,L"إصلاح الإقلاع [8]",L"Fix boot [8]",1,8,NULL,true,"Y\r\nN\r\nN\r\n"},
    {113,L"نقطة استعادة [13]",L"Restore point [13]",1,13,NULL},
    {120,L"استعادة النظام [20]",L"System Restore [20]",1,20,NULL},
    {121,L"أطر التشغيل [21]",L".NET runtimes [21]",1,21,NULL},
    {122,L"الوقت والتوقيت [22]",L"Time & timezone [22]",1,22,NULL},
    {123,L"متجر/UWP [23]",L"Store/UWP [23]",1,23,NULL},
    {124,L"WMI/Spooler [24]",L"WMI/Spooler [24]",1,24,NULL},
    {125,L"الأذونات [25]",L"Permissions [25]",1,25,NULL,true,"Y\r\nN\r\nN\r\n"},
    {126,L"أمن الشبكة [26]",L"Network security [26]",1,26,NULL,true,"Y\r\nY\r\nN\r\nN\r\n"},
};
static const BtnDef kClean[] = {
    {234,L"تنظيف عميق [34]",L"Deep cleanup [34]",2,34,NULL},
    {235,L"كاش المتصفحات [35]",L"Browser caches [35]",2,35,NULL},
    {236,L"WinSxS ResetBase [36]",L"WinSxS ResetBase [36]",2,36,NULL,true,"Y\r\nN\r\nN\r\n"},
};
static const BtnDef kCheck[] = {
    {304,L"فحص القرص [4]",L"Disk check [4]",3,4,NULL},
    {309,L"تحليل WinSxS [9]",L"Analyze WinSxS [9]",3,9,NULL},
    {310,L"أخطاء سجل الأحداث [10]",L"Event log errors [10]",3,10,NULL},
    {311,L"فحص الفيروسات [11]",L"Virus scan [11]",3,11,NULL},
    {312,L"فحص الذاكرة [12]",L"Memory test [12]",3,12,NULL},
    {327,L"الأقراص SMART/TRIM [27]",L"SMART/TRIM disks [27]",3,27,NULL},
    {328,L"تشخيص الشبكة [28]",L"Network diagnostics [28]",3,28,NULL},
    {329,L"الخدمات والأداء [29]",L"Services & performance [29]",3,29,NULL},
    {330,L"الانهيارات [30]",L"Crashes [30]",3,30,NULL},
    {331,L"التعافي والإقلاع [31]",L"Recovery & boot [31]",3,31,NULL},
    {332,L"الأمان Defender [32]",L"Defender security [32]",3,32,NULL},
    {333,L"معلومات النظام [33]",L"System info [33]",3,33,NULL},
};
static const BtnDef kMaint[] = {
    {419,L"مهمة فحص أسبوعية [19]",L"Weekly scan task [19]",4,19,NULL},
    {438,L"تصدير/فحص التعريفات [38]",L"Driver export/scan [38]",4,38,NULL},
    {439,L"تحديث البرامج winget [39]",L"Update apps via winget [39]",4,39,NULL},
    {440,L"تحديث ويندوز CLI [40]",L"Windows update (CLI) [40]",4,40,NULL},
};
static const BtnDef kReports[] = {
    {515,L"عرض التقرير [15]",L"View report [15]",5,15,NULL},
    {516,L"فتح مجلد التقارير [16]",L"Open reports folder [16]",5,16,NULL},
    {517,L"تصدير HTML/CSV [17]",L"Export HTML/CSV [17]",5,17,NULL},
    {518,L"إرسال بالبريد [18]",L"Email report [18]",5,18,NULL},
    {541,L"تصدير JSON [41]",L"Export JSON [41]",5,41,NULL},
    {542,L"تصدير PDF عبر Edge [42]",L"Export PDF via Edge [42]",5,42,NULL},
};
static const BtnDef kTools[] = {
    {614,L"جولة إصلاح شاملة [14]",L"Full repair run [14]",6,14,NULL},
    {643,L"PowerShell 7 [43]",L"PowerShell 7 [43]",6,43,NULL,true,"Y\r\nN\r\nN\r\n"},
    {644,L"إنشاء README [44]",L"Create README [44]",6,44,NULL},
    {645,L"أدوات إدارية [45]",L"Admin tools [45]",6,45,NULL,true,"Y\r\nN\r\nN\r\n"},
    {646,L"اختصار Dry-Run [46]",L"Dry-Run shortcut [46]",6,46,NULL},
    {9001,L"عرض المساعدة /help",L"Show help /help",0,0,L"/help"},
};
static const BtnDef kSettings[] = {
    {9002,L"جولة شاملة صامتة /silent",L"Silent full run /silent",0,0,L"/silent"},
    {9003,L"عرض المساعدة /help",L"Show help /help",0,0,L"/help"},
};

static int g_curTab = -1;
static const wchar_t* g_tabNamesAr[8] = {
    L"إصلاح", L"تنظيف", L"فحص", L"صيانة", L"تقارير", L"أدوات", L"سجل", L"إعدادات"
};
static const wchar_t* g_tabNamesEn[8] = {
    L"Repair", L"Cleanup", L"Check", L"Maintenance", L"Reports", L"Tools", L"Log", L"Settings"
};
static inline const wchar_t* TabName(int i) {
    return g_english ? g_tabNamesEn[i] : g_tabNamesAr[i];
}

static const BtnDef* g_allDefs[] = { kRepair, kClean, kCheck, kMaint, kReports, kTools, NULL, kSettings };
static const int g_allCounts[] = {
    (int)(sizeof(kRepair)/sizeof(BtnDef)), (int)(sizeof(kClean)/sizeof(BtnDef)),
    (int)(sizeof(kCheck)/sizeof(BtnDef)), (int)(sizeof(kMaint)/sizeof(BtnDef)),
    (int)(sizeof(kReports)/sizeof(BtnDef)), (int)(sizeof(kTools)/sizeof(BtnDef)),
    0, (int)(sizeof(kSettings)/sizeof(BtnDef))
};

static void CreateButtons(HWND parent, const BtnDef* defs, int count) {
    const int cols = 4, cw = 218, ch = 34, gapx = 8, gapy = 8, ox = 12, oy = 12;
    for (int i = 0; i < count; ++i) {
        int c = i % cols, r = i / cols;
        int x = ox + c * (cw + gapx);
        int y = oy + r * (ch + gapy);
        HWND h = CreateWindowExW(0, L"BUTTON", TR(defs[i].text, defs[i].en),
            WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON,
            x, y, cw, ch, parent, (HMENU)(INT_PTR)defs[i].id, g_inst, NULL);
        SendMessageW(h, WM_SETFONT, (WPARAM)g_font, TRUE);
        // tooltips
        static const wchar_t* rtipsAr[] = {
            L"فحص سريع - يجري فحصًا أساسيًا", L"إصلاح كامل - يشمل إصلاحات واسعة",
            L"إصلاح + تنظيف - يجمع بين الإصلاح والتنظيف", L"إصلاح مشاكل الشبكة",
            L"فحص/إصلاح Windows Update", L"إصلاح تسجيل ملفات DLL", L"إصلاح مشكلات الإقلاع (يتطلب تأكيدًا)",
            L"إنشاء أو التحقق من نقطة استعادة", L"فتح أداة استعادة النظام", L"فحص/إصلاح أطر .NET وغيرها",
            L"ضبط الوقت والتوقيت", L"مشكلات Microsoft Store/UWP", L"إصلاح WMI/Spooler",
            L"فحص/إصلاح صلاحيات النظام (يتطلب تأكيدًا)", L"إصلاح إعدادات أمان الشبكة (يتطلب تأكيدًا)"
        };
        static const wchar_t* rtipsEn[] = {
            L"Quick scan - basic check", L"Full repair - broad repairs",
            L"Repair + cleanup", L"Fix network issues",
            L"Check/repair Windows Update", L"Re-register DLLs", L"Fix boot problems (confirmation required)",
            L"Create or verify a restore point", L"Open System Restore", L"Check/repair .NET runtimes",
            L"Set time and timezone", L"Microsoft Store/UWP issues", L"Repair WMI/Spooler",
            L"Check/repair system permissions (confirmation required)", L"Fix network security settings (confirmation required)"
        };
        if (count == (int)(sizeof(kRepair)/sizeof(BtnDef))) {
            if (i < (int)(sizeof(rtipsAr)/sizeof(rtipsAr[0]))) AddToolTip(h, TR(rtipsAr[i], rtipsEn[i]));
        }
        if (count == (int)(sizeof(kClean)/sizeof(BtnDef))) {
            if (i == 0) AddToolTip(h, TR(L"تنظيف مؤقتات وأرشيفات", L"Clean temp files and archives"));
            if (i == 1) AddToolTip(h, TR(L"تفريغ ذاكرة التخزين للمتصفحات", L"Clear browser caches"));
            if (i == 2) AddToolTip(h, TR(L"WinSxS Component Store - ResetBase بحذر (يتطلب تأكيدًا)", L"WinSxS Component Store - ResetBase (confirmation required)"));
        }
        if (count == (int)(sizeof(kCheck)/sizeof(BtnDef))) {
            if (i == 0) AddToolTip(h, TR(L"فحص سلامة القرص", L"Check disk health"));
            if (i == 1) AddToolTip(h, TR(L"تحليل/فحص حزم WinSxS", L"Analyze/check WinSxS packages"));
            if (i == 2) AddToolTip(h, TR(L"تحليل أخطاء سجل الأحداث", L"Analyze event log errors"));
            if (i == 3) AddToolTip(h, TR(L"فحص مبسط للأمن", L"Basic security check"));
            if (i == 4) AddToolTip(h, TR(L"فحص الذاكرة RAM", L"Test RAM memory"));
            if (i == 5) AddToolTip(h, TR(L"حالة الأقراص SMART/Trim", L"SMART/TRIM disk status"));
            if (i == 6) AddToolTip(h, TR(L"تشخيص اتصال الشبكة", L"Diagnose network connectivity"));
            if (i == 7) AddToolTip(h, TR(L"تحقق من الخدمات والأداء", L"Verify services and performance"));
            if (i == 8) AddToolTip(h, TR(L"تحليل آخر الانهيارات", L"Analyze recent crashes"));
            if (i == 9) AddToolTip(h, TR(L"تحقق من التعافي والإقلاع", L"Check recovery and boot"));
            if (i == 10) AddToolTip(h, TR(L"حالة Windows Defender", L"Windows Defender status"));
            if (i == 11) AddToolTip(h, TR(L"معلومات شاملة عن النظام", L"Comprehensive system information"));
        }
        if (count == (int)(sizeof(kMaint)/sizeof(BtnDef))) {
            if (i == 0) AddToolTip(h, TR(L"تشغيل فحص دوري", L"Run a periodic scan"));
            if (i == 1) AddToolTip(h, TR(L"تصدير/فحص قائمة التعريفات", L"Export/scan the driver list"));
            if (i == 2) AddToolTip(h, TR(L"تحديث البرامج عبر winget", L"Update apps via winget"));
            if (i == 3) AddToolTip(h, TR(L"تحديثات ويندوز عبر CLI", L"Windows updates via CLI"));
        }
        if (count == (int)(sizeof(kReports)/sizeof(BtnDef))) {
            if (i == 0) AddToolTip(h, TR(L"عرض أحدث تقرير تلقائي", L"View the latest report"));
            if (i == 1) AddToolTip(h, TR(L"فتح مجلد تقارير الإصلاح", L"Open the repairs report folder"));
            if (i == 2) AddToolTip(h, TR(L"تصدير التقرير بصيغ HTML/CSV", L"Export the report as HTML/CSV"));
            if (i == 3) AddToolTip(h, TR(L"فتح قوالب إرسال التقرير", L"Prepare the report for emailing"));
            if (i == 4) AddToolTip(h, TR(L"تصدير التقرير بصيغة JSON", L"Export the report as JSON"));
            if (i == 5) AddToolTip(h, TR(L"تصدير التقرير كملف PDF", L"Export the report as PDF"));
        }
        if (count == (int)(sizeof(kTools)/sizeof(BtnDef))) {
            if (i == 0) AddToolTip(h, TR(L"جولة إصلاح متكاملة لعدة أقسام", L"Integrated multi-section repair run"));
            if (i == 1) AddToolTip(h, TR(L"تشغيل PowerShell 7 (يتطلب تأكيدًا للتنصيب)", L"Launch or install PowerShell 7 (confirmation required)"));
            if (i == 2) AddToolTip(h, TR(L"إنشاء ملف README للنظام", L"Create a system README file"));
            if (i == 3) AddToolTip(h, TR(L"فتح أدوات Windows الإدارية (يتطلب تأكيدًا)", L"Open Windows administrative tools (confirmation required)"));
            if (i == 4) AddToolTip(h, TR(L"اختصار لتشغيل Dry-Run", L"Shortcut to run Dry-Run"));
            if (i == 5) AddToolTip(h, TR(L"عرض تعليمات الاستخدام", L"Show usage help"));
        }
        if (count == (int)(sizeof(kSettings)/sizeof(BtnDef))) {
            if (i == 0) AddToolTip(h, TR(L"تشغيل جولة إصلاح صامتة", L"Run a silent repair pass"));
            if (i == 1) AddToolTip(h, TR(L"عرض تعليمات الاستخدام", L"Show usage help"));
        }
    }
}

static HWND FirstFocusable(HWND parent) {
    HWND c = GetWindow(parent, GW_CHILD);
    while (c) {
        LONG st = GetWindowLongW(c, GWL_STYLE);
        if ((st & WS_TABSTOP) && (st & WS_VISIBLE) && IsWindowEnabled(c))
            return c;
        c = GetWindow(c, GW_HWNDNEXT);
    }
    return NULL;
}

static void CollectFocusables(std::vector<HWND>& v) {
    v.clear();
    if (g_hTab) v.push_back(g_hTab);
    HWND page = (g_curTab >= 0 && g_curTab < 8) ? g_pages[g_curTab] : NULL;
    if (page && IsWindowVisible(page)) {
        LONG pst = GetWindowLongW(page, GWL_STYLE);
        if ((pst & WS_TABSTOP) && IsWindowEnabled(page)) {
            v.push_back(page);
        } else {
            for (HWND c = GetWindow(page, GW_CHILD); c; c = GetWindow(c, GW_HWNDNEXT)) {
                LONG st = GetWindowLongW(c, GWL_STYLE);
                if ((st & WS_TABSTOP) && (st & WS_VISIBLE) && IsWindowEnabled(c)) v.push_back(c);
            }
        }
    }
    if (g_hMin) v.push_back(g_hMin);
    if (g_hExit) v.push_back(g_hExit);
}

static HWND NextInRing(HWND cur, bool shift) {
    std::vector<HWND> v;
    CollectFocusables(v);
    int n = (int)v.size();
    if (n == 0) return NULL;
    int idx = -1;
    for (int i = 0; i < n; ++i) if (v[i] == cur) { idx = i; break; }
    int nx;
    if (idx < 0) nx = shift ? n - 1 : 0;
    else nx = shift ? (idx - 1 + n) % n : (idx + 1) % n;
    return v[nx];
}

static void BuildPage(int idx) {
    if (g_pages[idx]) { ShowWindow(g_pages[idx], SW_SHOW); return; }
    HWND page = CreateWindowExW(WS_EX_CONTROLPARENT | (Rtl() ? WS_EX_LAYOUTRTL : 0), L"RepairPage", L"",
        WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 0, 0, 10, 10, g_hMain, NULL, g_inst, NULL);
    g_pages[idx] = page;
    if (idx >= 0 && idx < 8) SetWindowTextW(page, TabName(idx));
    switch (idx) {
        case 0: CreateButtons(page, kRepair, g_allCounts[0]); break;
        case 1: CreateButtons(page, kClean, g_allCounts[1]); break;
        case 2: CreateButtons(page, kCheck, g_allCounts[2]); break;
        case 3: CreateButtons(page, kMaint, g_allCounts[3]); break;
        case 4: CreateButtons(page, kReports, g_allCounts[4]); break;
        case 5: CreateButtons(page, kTools, g_allCounts[5]); break;
        case 7: {
            CreateButtons(page, kSettings, g_allCounts[7]);
            g_hDry = CreateWindowExW(Rtl() ? WS_EX_LAYOUTRTL : 0, L"BUTTON",
                TR(L"محاكاة بدون تنفيذ (Dry-Run)", L"Simulate only (Dry-Run)"),
                WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_AUTOCHECKBOX,
                12, 120, 420, 30, page, (HMENU)ID_DRY, g_inst, NULL);
            SendMessageW(g_hDry, WM_SETFONT, (WPARAM)g_font, TRUE);
            AddToolTip(g_hDry, TR(L"محاكاة بدون تنفيذ - يعرض الخطوات دون تغيير النظام (يمرّر /dry-run)",
                                  L"Dry-run - shows steps without changing the system (passes /dry-run)"));
            HWND lbl = CreateWindowExW(Rtl() ? WS_EX_LAYOUTRTL : 0, L"STATIC", TR(L"اللغة:", L"Language:"),
                WS_CHILD | WS_VISIBLE | SS_LEFT,
                12, 164, 120, 22, page, NULL, g_inst, NULL);
            SendMessageW(lbl, WM_SETFONT, (WPARAM)g_font, TRUE);
            g_hLangAr = CreateWindowExW(Rtl() ? WS_EX_LAYOUTRTL : 0, L"BUTTON", L"العربية",
                WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_AUTORADIOBUTTON | WS_GROUP,
                140, 160, 140, 28, page, (HMENU)ID_LANG_AR, g_inst, NULL);
            g_hLangEn = CreateWindowExW(Rtl() ? WS_EX_LAYOUTRTL : 0, L"BUTTON", L"English",
                WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_AUTORADIOBUTTON,
                290, 160, 140, 26, page, (HMENU)ID_LANG_EN, g_inst, NULL);
            SendMessageW(g_hLangAr, WM_SETFONT, (WPARAM)g_font, TRUE);
            SendMessageW(g_hLangEn, WM_SETFONT, (WPARAM)g_font, TRUE);
            SendMessageW(g_hLangAr, BM_SETCHECK, g_english ? BST_UNCHECKED : BST_CHECKED, 0);
            SendMessageW(g_hLangEn, BM_SETCHECK, g_english ? BST_CHECKED : BST_UNCHECKED, 0);
            break;
        }
    }
}

static void RearmWindowButtons() {
    SetWindowPos(g_hMin, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    SetWindowPos(g_hExit, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

static void ShowTab(int idx) {
    RECT rc;
    GetClientRect(g_hTab, &rc);
    TabCtrl_AdjustRect(g_hTab, FALSE, &rc);
    MapWindowPoints(g_hTab, g_hMain, (LPPOINT)&rc, 2);
    for (int i = 0; i < 8; ++i) {
        if (!g_pages[i]) continue;
        if (i == idx) {
            MoveWindow(g_pages[i], rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, TRUE);
            ShowWindow(g_pages[i], SW_SHOW);
            if (i == 6 && g_hLog && g_hSaveLog) {
                RECT pr;
                GetClientRect(g_pages[6], &pr);
                int pad = 8, bw = 150, bh = 30;
                int bx = pr.right - pad - bw;
                SetWindowPos(g_hSaveLog, NULL, bx, pr.bottom - pad - bh, bw, bh, SWP_NOZORDER);
                MoveWindow(g_hLog, pad, pad, pr.right - 2 * pad, pr.bottom - 3 * pad - bh, TRUE);
            }
        } else {
            ShowWindow(g_pages[i], SW_HIDE);
        }
    }
    RearmWindowButtons();
    g_curTab = idx;
}

static void RestoreUiState() {
    bool done = false;
    if (g_lastFocusRoot == -1) {
        SetFocus(g_hTab);
        done = true;
    } else if (g_lastFocusRoot >= 0 && g_lastFocusRoot == g_selTab && g_pages[g_lastFocusRoot]) {
        HWND h = GetDlgItem(g_pages[g_lastFocusRoot], g_lastFocusId);
        if (h && IsWindowVisible(h) && IsWindowEnabled(h)) { SetFocus(h); done = true; }
    } else if (g_lastFocusRoot == -2) {
        HWND h = GetDlgItem(g_hMain, g_lastFocusId);
        if (h && IsWindowVisible(h) && IsWindowEnabled(h)) { SetFocus(h); done = true; }
    }
    if (!done) SetFocus(g_hTab);
    if (g_lastMouseX >= 0 && g_lastMouseY >= 0) {
        int vx = GetSystemMetrics(SM_XVIRTUALSCREEN);
        int vy = GetSystemMetrics(SM_YVIRTUALSCREEN);
        int vw = GetSystemMetrics(SM_CXVIRTUALSCREEN);
        int vh = GetSystemMetrics(SM_CYVIRTUALSCREEN);
        if (g_lastMouseX >= vx && g_lastMouseX < vx + vw &&
            g_lastMouseY >= vy && g_lastMouseY < vy + vh)
            SetCursorPos(g_lastMouseX, g_lastMouseY);
    }
}

static void InitTabs() {
    for (int i = 0; i < 8; ++i) {
        TCITEMW ti = { 0 };
        ti.mask = TCIF_TEXT;
        ti.pszText = (LPWSTR)TabName(i);
        TabCtrl_InsertItem(g_hTab, i, &ti);
    }
    HWND logPage = CreateWindowExW(WS_EX_CONTROLPARENT | (Rtl() ? WS_EX_LAYOUTRTL : 0), L"RepairPage", L"",
        WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 0, 0, 10, 10, g_hMain, NULL, g_inst, NULL);
    g_pages[6] = logPage;
    g_hLog = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL,
        0, 0, 100, 100, logPage, (HMENU)ID_LOG, g_inst, NULL);
    SendMessageW(g_hLog, WM_SETFONT, (WPARAM)g_logFont, TRUE);
    g_hSaveLog = CreateWindowExW(0, L"BUTTON", TR(L"حفظ السجل", L"Save log"),
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON,
        0, 0, 150, 30, logPage, (HMENU)ID_SAVELOG, g_inst, NULL);
    SendMessageW(g_hSaveLog, WM_SETFONT, (WPARAM)g_font, TRUE);
    AddToolTip(g_hSaveLog, TR(L"حفظ محتوى السجل في ملف", L"Save the log content to a file"));
}

static void LayoutMain() {
    if (!g_hMain) return;
    RECT rc;
    GetClientRect(g_hMain, &rc);
    int statusH = 24;
    int topH = 42;
    int W = rc.right;
    if (Rtl()) {
        SetWindowPos(g_hExit, NULL, W - 6 - 190, 8, 190, 28, SWP_NOZORDER);
        SetWindowPos(g_hMin, NULL, W - 6 - 190 - 12 - 190, 8, 190, 28, SWP_NOZORDER);
    } else {
        SetWindowPos(g_hExit, NULL, 6, 8, 190, 28, SWP_NOZORDER);
        SetWindowPos(g_hMin, NULL, 208, 8, 190, 28, SWP_NOZORDER);
    }
    SetWindowPos(g_hTab, NULL, 6, topH, W - 12, rc.bottom - topH - statusH - 12, SWP_NOZORDER);
    SetWindowPos(g_hStatus, NULL, 6, rc.bottom - statusH - 4, W - 12, 20, SWP_NOZORDER);
}

static void ApplyDirection() {
    bool rtl = Rtl();
    if (g_hStatus) {
        LONG st = GetWindowLongW(g_hStatus, GWL_STYLE);
        st &= ~(0x0000000FL);
        st |= rtl ? SS_RIGHT : SS_LEFTNOWORDWRAP;
        SetWindowLongW(g_hStatus, GWL_STYLE, st);
        InvalidateRect(g_hStatus, NULL, TRUE);
    }
    if (g_hTab) {
        LONG ex = GetWindowLongW(g_hTab, GWL_EXSTYLE);
        ex &= ~WS_EX_LAYOUTRTL;
        if (rtl) ex |= WS_EX_LAYOUTRTL;
        SetWindowLongW(g_hTab, GWL_EXSTYLE, ex);
        SetWindowPos(g_hTab, NULL, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
        InvalidateRect(g_hTab, NULL, TRUE);
    }
    if (g_pages[6]) {
        LONG ex = GetWindowLongW(g_pages[6], GWL_EXSTYLE);
        ex &= ~WS_EX_LAYOUTRTL;
        if (rtl) ex |= WS_EX_LAYOUTRTL;
        SetWindowLongW(g_pages[6], GWL_EXSTYLE, ex);
    }
}

static void ApplyLanguage() {
    if (g_hTip) HideKeyboardTip();
    g_pendingCtrl = NULL;
    g_pendingText.clear();

    SetWindowTextW(g_hMain, TR(L"نظام إصلاح ويندوز - Windows Repair Toolkit",
                               L"Windows Repair Toolkit"));
    if (g_hMin) SetWindowTextW(g_hMin, TR(L"تصغير (Ctrl+M)", L"Minimize (Ctrl+M)"));
    if (g_hExit) SetWindowTextW(g_hExit, TR(L"خروج (Ctrl+Q)", L"Exit (Ctrl+Q)"));
    if (g_hSaveLog) SetWindowTextW(g_hSaveLog, TR(L"حفظ السجل", L"Save log"));

    for (int i = 0; i < 8; ++i) {
        TCITEMW ti = { 0 };
        ti.mask = TCIF_TEXT;
        ti.pszText = (LPWSTR)TabName(i);
        TabCtrl_SetItem(g_hTab, i, &ti);
    }

    if (g_hTip) {
        for (size_t i = 0; i < g_tips.size(); ++i) {
            TOOLINFOW ti = { sizeof(ti) };
            ti.hwnd = GetParent(g_tips[i].h) ? GetParent(g_tips[i].h) : g_hMain;
            ti.uId = (UINT_PTR)g_tips[i].h;
            SendMessageW(g_hTip, TTM_DELTOOLW, 0, (LPARAM)&ti);
        }
    }
    g_tips.clear();

    for (int i = 0; i < 8; ++i) {
        if (i == 6) continue;
        if (g_pages[i]) { DestroyWindow(g_pages[i]); g_pages[i] = NULL; }
    }
    g_hDry = NULL;

    AddToolTip(g_hMin, TR(L"تصغير النافذة (Ctrl+M)", L"Minimize the window (Ctrl+M)"));
    AddToolTip(g_hExit, TR(L"إغلاق البرنامج مع إلغاء أي عملية قيد التشغيل والتفريغ الكامل (Ctrl+Q)",
                           L"Close the program and abort any running operation (Ctrl+Q)"));
    AddToolTip(g_hStatus, TR(L"حالة التشغيل الحالية", L"Current run status"));

    ApplyDirection();
    LayoutMain();
    if (g_curTab >= 0 && g_curTab < 8 && g_curTab != 6) BuildPage(g_curTab);
    ShowTab(g_curTab);

    if (g_hSaveLog) AddToolTip(g_hSaveLog, TR(L"حفظ محتوى السجل في ملف", L"Save the log content to a file"));

    if (!g_busy) SetStatus(TR(L"جاهز", L"Ready"));

    if (g_curTab == 7) {
        HWND f = g_english ? g_hLangEn : g_hLangAr;
        SetFocus(f ? f : g_hTab);
    } else if (g_hTab) {
        SetFocus(g_hTab);
    }
}

static std::wstring FindNewestReport() {
    std::wstring dir = L"C:\\Windows\\Logs\\Repair";
    std::wstring pattern = dir + L"\\RepairReport_*.txt";
    WIN32_FIND_DATAW fd;
    HANDLE hf = FindFirstFileW(pattern.c_str(), &fd);
    if (hf == INVALID_HANDLE_VALUE) return std::wstring();
    std::wstring best = dir + L"\\" + fd.cFileName;
    ULONGLONG bestTime = ((ULONGLONG)fd.ftLastWriteTime.dwHighDateTime << 32) | fd.ftLastWriteTime.dwLowDateTime;
    while (FindNextFileW(hf, &fd)) {
        ULONGLONG t = ((ULONGLONG)fd.ftLastWriteTime.dwHighDateTime << 32) | fd.ftLastWriteTime.dwLowDateTime;
        if (t > bestTime) { bestTime = t; best = dir + L"\\" + fd.cFileName; }
    }
    FindClose(hf);
    return best;
}

static void OpenLatestReport() {
    std::wstring r = FindNewestReport();
    if (r.empty()) { LogAppend(TR(L"(لا يوجد تقرير بعد - شغّل أي عملية أولاً)",
                                  L"(No report yet - run any operation first)")); return; }
    LogAppend(std::wstring(TR(L"(فتح التقرير: ", L"(Opening report: ")) + r + L")");
    ShellExecuteW(g_hMain, L"open", r.c_str(), NULL, NULL, SW_SHOWNORMAL);
}

static void OpenReportFolder() {
    LogAppend(TR(L"(فتح مجلد التقارير: C:\\Windows\\Logs\\Repair)",
                 L"(Opening reports folder: C:\\Windows\\Logs\\Repair)"));
    ShellExecuteW(g_hMain, L"open", L"C:\\Windows\\Logs\\Repair", NULL, NULL, SW_SHOWNORMAL);
}

static void RunHiddenWait(const std::wstring& cmdline) {
    STARTUPINFOW si = { sizeof(si) };
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi = { 0 };
    std::wstring c = cmdline;
    if (!c.empty() && CreateProcessW(NULL, &c[0], NULL, NULL, FALSE,
        CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        WaitForSingleObject(pi.hProcess, 3000);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
}

static void KillRunningTree() {
    if (!g_childPid) return;
    if (g_hJob) TerminateJobObject(g_hJob, 1);
    if (g_hChild) TerminateProcess(g_hChild, 1);
    wchar_t sys[MAX_PATH] = { 0 };
    GetSystemDirectoryW(sys, MAX_PATH);
    RunHiddenWait(std::wstring(sys) + L"\\taskkill.exe /F /T /PID " + std::to_wstring(g_childPid));
    if (g_hWorker) WaitForSingleObject(g_hWorker, 5000);
}

static void ClearUiState() {
    g_lastFocusRoot = -3;
    g_lastFocusId = 0;
    g_lastMouseX = -1;
    g_lastMouseY = -1;
}

static void SaveWindowState() {
    if (g_hMain) {
        RECT r;
        if (GetWindowRect(g_hMain, &r)) {
            g_winW = r.right - r.left;
            g_winH = r.bottom - r.top;
        }
    }
    if (g_hTab) {
        int cur = TabCtrl_GetCurSel(g_hTab);
        if (cur >= 0 && cur < 8) g_selTab = cur;
    }
    SaveSettings();
}

static void FullUnload() {
    if (g_exiting) return;
    g_exiting = true;

    if (g_busy) SetStatus(TR(L"جارٍ إلغاء التحميل...", L"Unloading..."));
    SaveWindowState();
    KillRunningTree();

    MSG m;
    while (PeekMessageW(&m, NULL, WM_RUN_DONE, WM_RUN_DONE, PM_REMOVE))
        delete (std::wstring*)m.wParam;

    if (!g_curIn.empty()) DeleteFileW(g_curIn.c_str());
    if (!g_curOut.empty()) DeleteFileW(g_curOut.c_str());

    if (g_hChild) { CloseHandle(g_hChild); g_hChild = NULL; }
    if (g_hWorker) { CloseHandle(g_hWorker); g_hWorker = NULL; }
    if (g_hJob) { CloseHandle(g_hJob); g_hJob = NULL; }
    g_childPid = 0;
    g_busy = false;
    g_curIn.clear();
    g_curOut.clear();

    if (g_hMain) DestroyWindow(g_hMain);
    if (g_font) { DeleteObject(g_font); g_font = NULL; }
    if (g_logFont) { DeleteObject(g_logFont); g_logFont = NULL; }
}

static void HandleButton(int id) {
    if (id == ID_MINIMIZE) { ShowWindow(g_hMain, SW_MINIMIZE); return; }
    if (id == ID_EXIT) { SendMessageW(g_hMain, WM_CLOSE, 0, 0); return; }
    if (id == 515) { OpenLatestReport(); return; }
    if (id == 516) { OpenReportFolder(); return; }
    for (int t = 0; t < 8; ++t) {
        if (!g_allDefs[t]) continue;
        for (int i = 0; i < g_allCounts[t]; ++i) {
            if (g_allDefs[t][i].id == id) {
                const BtnDef& b = g_allDefs[t][i];
                if (b.direct) { RunDirect(b.direct); return; }
                if (b.confirm && !DryRunEnabled()) {
                    if (MessageBoxW(g_hMain,
                            TR(L"تحذير: هذه العملية تُجري تغييرات جذرية على النظام وقد يصعب التراجع عنها.\n\nهل تريد المتابعة؟",
                               L"Warning: this operation makes significant system changes that may be hard to undo.\n\nContinue?"),
                            TR(L"عملية حساسة - تأكيد", L"Sensitive operation - confirm"),
                            MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) return;
                    const char* in = b.yesIn;
                    if (b.id == 643) in = PwshInstalled() ? "N\r\nN\r\n" : "Y\r\nN\r\nN\r\n";
                    RunSection(b.group, b.section, in);
                } else {
                    RunSection(b.group, b.section);
                }
                return;
            }
        }
    }
}

static void SaveLog() {
    if (!g_hLog) return;
    int len = GetWindowTextLengthW(g_hLog);
    std::wstring txt((size_t)len + 1, 0);
    GetWindowTextW(g_hLog, &txt[0], len + 1);
    txt.resize((size_t)len);
    if (txt.empty()) { SetStatus(TR(L"السجل فارغ", L"The log is empty")); return; }

    SYSTEMTIME st;
    GetLocalTime(&st);
    wchar_t file[MAX_PATH];
    wsprintfW(file, L"RepairLog_%04d%02d%02d_%02d%02d%02d.txt",
        st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);

    OPENFILENAMEW ofn;
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = g_hMain;
    ofn.lpstrFilter = L"Text (*.txt)\0*.txt\0All files (*.*)\0*.*\0\0";
    ofn.lpstrFile = file;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = L"txt";
    ofn.lpstrTitle = TR(L"حفظ السجل", L"Save log");
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_EXPLORER;
    if (!GetSaveFileNameW(&ofn)) return;

    int n = WideCharToMultiByte(CP_UTF8, 0, txt.c_str(), (int)txt.size(), NULL, 0, NULL, NULL);
    std::string u8((size_t)n, 0);
    if (n > 0) WideCharToMultiByte(CP_UTF8, 0, txt.c_str(), (int)txt.size(), &u8[0], n, NULL, NULL);
    HANDLE f = CreateFileW(file, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f == INVALID_HANDLE_VALUE) { SetStatus(TR(L"تعذّر حفظ السجل", L"Failed to save the log")); return; }
    DWORD wr;
    const unsigned char bom[3] = { 0xEF, 0xBB, 0xBF };
    WriteFile(f, bom, 3, &wr, NULL);
    if (!u8.empty()) WriteFile(f, u8.data(), (DWORD)u8.size(), &wr, NULL);
    CloseHandle(f);
    SetStatus(TR(L"تم حفظ السجل", L"Log saved"));
}

static LRESULT CALLBACK PageProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
        case WM_COMMAND:
        case WM_NOTIFY:
        case WM_CONTEXTMENU:
            return SendMessageW(g_hMain, m, w, l);
        case WM_CTLCOLORSTATIC:
            SetBkColor((HDC)w, GetSysColor(COLOR_BTNFACE));
            return (LRESULT)GetSysColorBrush(COLOR_BTNFACE);
        case WM_CTLCOLOREDIT:
            return (LRESULT)GetSysColorBrush(COLOR_WINDOW);
    }
    return DefWindowProcW(h, m, w, l);
}

static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
        case WM_GETMINMAXINFO: {
            MINMAXINFO* mmi = (MINMAXINFO*)l;
            mmi->ptMinTrackSize.x = 960;
            mmi->ptMinTrackSize.y = 600;
            return 0;
        }
        case WM_SIZE: {
            LayoutMain();
            if (g_curTab >= 0) ShowTab(g_curTab);
            return 0;
        }
        case WM_CONTEXTMENU: {
            HWND under;
            int cx = (short)LOWORD(l), cy = (short)HIWORD(l);
            if (cx == -1 && cy == -1) {
                under = (HWND)w;
                if (!under || under == g_hMain) under = GetFocus();
            } else {
                POINT pt = { cx, cy };
                under = WindowFromPoint(pt);
            }
            if (under) {
                std::wstring t = TipFor(under);
                if (!t.empty()) { ShowKeyboardTip(under, t); return 0; }
            }
            return 0;
        }
        case WM_TIMER:
            if (w == TIMER_TIP) {
                KillTimer(h, TIMER_TIP);
                if (g_pendingCtrl && !g_pendingText.empty()) {
                    MarkKbTipShown(g_pendingCtrl);
                    ShowKeyboardTip(g_pendingCtrl, g_pendingText);
                }
                return 0;
            }
            if (w == TIMER_TIP_HIDE) {
                KillTimer(h, TIMER_TIP_HIDE);
                HideKeyboardTip();
                return 0;
            }
            break;
        case WM_NOTIFY: {
            LPNMHDR nh = (LPNMHDR)l;
            if (nh && nh->hwndFrom == g_hTip && nh->code == TTN_GETDISPINFOW) {
                LPNMTTDISPINFOW di = (LPNMTTDISPINFOW)l;
                UINT_PTR id = di->hdr.idFrom;
                if ((HWND)id == g_hTab) {
                    int cur = -1;
                    POINT pt;
                    if (GetCursorPos(&pt)) {
                        MapWindowPoints(NULL, g_hTab, &pt, 1);
                        TCHITTESTINFO hti = { 0 };
                        hti.pt = pt;
                        cur = (int)SendMessageW(g_hTab, TCM_HITTEST, 0, (LPARAM)&hti);
                    }
                    if (cur < 0) cur = TabCtrl_GetCurSel(g_hTab);
                    if (cur >= 0 && cur < 8) di->lpszText = (LPWSTR)TR(g_tabTipsAr[cur], g_tabTipsEn[cur]);
                } else if (id == TIP_TRACK_ID) {
                    di->lpszText = (LPWSTR)g_trackTip.c_str();
                } else {
                    std::wstring t = TipTextFor((HWND)id);
                    if (!t.empty()) {
                        static wchar_t buf[512];
                        lstrcpynW(buf, t.c_str(), 512);
                        di->lpszText = buf;
                    }
                }
                return 0;
            }
            if (nh && nh->hwndFrom == g_hTip && nh->code == TTN_POP) {
                HWND c = (HWND)nh->idFrom;
                if (c && (UINT_PTR)c != TIP_TRACK_ID &&
                    (c == g_hTab || !TipTextFor(c).empty()))
                    PostMessageW(g_hMain, WM_TIP_DONE, (WPARAM)c, 0);
                return 0;
            }
            if (nh && nh->hwndFrom == g_hTab && nh->code == TCN_SELCHANGE) {
                int idx = TabCtrl_GetCurSel(g_hTab);
                BuildPage(idx);
                ShowTab(idx);
                SetFocus(g_hTab);
            }
            return 0;
        }
        case WM_COMMAND: {
            int id = LOWORD(w);
            if (id == ID_LANG_AR || id == ID_LANG_EN) {
                bool en = (id == ID_LANG_EN);
                if (en != g_english) { g_english = en; ApplyLanguage(); SaveSettings(); }
                return 0;
            }
            if (id == ID_SAVELOG) { SaveLog(); return 0; }
            if (id != ID_LOG && id != ID_DRY) HandleButton(id);
            return 0;
        }
        case WM_RUN_DONE: {
            std::wstring* s = (std::wstring*)w;
            LogAppend(*s);
            delete s;
            if (g_hChild) { CloseHandle(g_hChild); g_hChild = NULL; }
            if (g_hWorker) { CloseHandle(g_hWorker); g_hWorker = NULL; }
            g_childPid = 0;
            g_busy = false;
            SetStatus(TR(L"جاهز", L"Ready"));
            return 0;
        }
        case WM_TIP_DONE:
            RemoveTipTool((HWND)w);
            return 0;
        case WM_CLOSE:
            ClearUiState();
            if (g_busy) {
                if (MessageBoxW(g_hMain,
                        TR(L"تنبيه: هناك عملية قيد التنفيذ الآن.\n"
                           L"إذا أغلقت البرنامج سيتم إلغاء العملية الحالية فوراً.\n\n"
                           L"هل تريد الإغلاق مع إلغاء العملية؟",
                           L"Warning: an operation is currently running.\n"
                           L"If you close the program, the current operation will be aborted.\n\n"
                           L"Close and cancel the operation?"),
                        TR(L"تحذير - عملية قيد التنفيذ", L"Warning - operation in progress"),
                        MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) return 0;
            } else {
                if (MessageBoxW(g_hMain,
                        TR(L"هل تريد إغلاق البرنامج؟", L"Do you want to close the program?"),
                        TR(L"تأكيد الخروج", L"Confirm exit"),
                        MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2) != IDYES) return 0;
            }
            FullUnload();
            return 0;
        case WM_DESTROY:
            if (!g_exiting) {
                ClearUiState();
                FullUnload();
            }
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

static void SelfTest(int g, int s) {
    if (g > 0) {
        RunSection(g, s);
    } else {
        BuildPage(5);
        HWND hb = GetDlgItem(g_pages[5], 9001);
        SendMessageW(hb, BM_CLICK, 0, 0);
    }
    DWORD start = GetTickCount();
    MSG m2;
    while (g_busy && GetTickCount() - start < 180000) {
        while (PeekMessageW(&m2, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&m2);
            DispatchMessageW(&m2);
        }
        Sleep(20);
    }
    for (int i = 0; i < 20; ++i) {
        while (PeekMessageW(&m2, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&m2);
            DispatchMessageW(&m2);
        }
        Sleep(10);
    }
    int len = GetWindowTextLengthW(g_hLog);
    std::wstring txt((size_t)len + 1, 0);
    GetWindowTextW(g_hLog, &txt[0], len + 1);
    txt.resize((size_t)len);
    int n = WideCharToMultiByte(CP_UTF8, 0, txt.c_str(), (int)txt.size(), NULL, 0, NULL, NULL);
    std::string u8(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, txt.c_str(), (int)txt.size(), &u8[0], n, NULL, NULL);
    wchar_t stDir[32768] = { 0 };
    GetTempPathW(32768, stDir);
    std::wstring stPath = std::wstring(stDir) + L"repairui_selftest.txt";
    HANDLE f = CreateFileW(stPath.c_str(), GENERIC_WRITE, 0, NULL,
        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f != INVALID_HANDLE_VALUE) {
        DWORD wr;
        const unsigned char bom[3] = { 0xEF, 0xBB, 0xBF };
        WriteFile(f, bom, 3, &wr, NULL);
        WriteFile(f, u8.empty() ? "" : u8.c_str(), (DWORD)u8.size(), &wr, NULL);
        CloseHandle(f);
    }
    DestroyWindow(g_hMain);
}

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE, LPWSTR, int) {
    g_inst = inst;
    LoadSettings();
    INITCOMMONCONTROLSEX icc = { sizeof(icc), ICC_TAB_CLASSES | ICC_STANDARD_CLASSES };
    InitCommonControlsEx(&icc);

    g_font = CreateFontW(-16, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
        DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
    g_logFont = CreateFontW(-15, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
        FIXED_PITCH | FF_MODERN, L"Consolas");

    WNDCLASSEXW wc = { sizeof(wc) };
    wc.lpfnWndProc = WndProc;
    wc.hInstance = inst;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = L"RepairUIToolkit";
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
    RegisterClassExW(&wc);

    WNDCLASSEXW pc = { sizeof(pc) };
    pc.lpfnWndProc = PageProc;
    pc.hInstance = inst;
    pc.hCursor = LoadCursor(NULL, IDC_ARROW);
    pc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    pc.lpszClassName = L"RepairPage";
    RegisterClassExW(&pc);

    g_hMain = CreateWindowExW(
        WS_EX_CONTROLPARENT,
        L"RepairUIToolkit",
        TR(L"نظام إصلاح ويندوز - Windows Repair Toolkit", L"Windows Repair Toolkit"),
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, g_winW, g_winH,
        NULL, NULL, inst, NULL);

    g_hTab = CreateWindowExW(0, WC_TABCONTROL, L"",
        WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_TABSTOP | TCS_HOTTRACK,
        0, 0, 100, 100, g_hMain, (HMENU)1000, inst, NULL);
    SendMessageW(g_hTab, WM_SETFONT, (WPARAM)g_font, TRUE);

    g_hExit = CreateWindowExW(0, L"BUTTON", TR(L"خروج (Ctrl+Q)", L"Exit (Ctrl+Q)"),
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON,
        0, 0, 190, 28, g_hMain, (HMENU)ID_EXIT, inst, NULL);
    SendMessageW(g_hExit, WM_SETFONT, (WPARAM)g_font, TRUE);
    g_hMin = CreateWindowExW(0, L"BUTTON", TR(L"تصغير (Ctrl+M)", L"Minimize (Ctrl+M)"),
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON,
        0, 0, 190, 28, g_hMain, (HMENU)ID_MINIMIZE, inst, NULL);
    SendMessageW(g_hMin, WM_SETFONT, (WPARAM)g_font, TRUE);

    g_hStatus = CreateWindowExW(0, L"STATIC", TR(L"جاهز", L"Ready"),
        WS_CHILD | WS_VISIBLE | SS_LEFTNOWORDWRAP,
        0, 0, 100, 20, g_hMain, NULL, inst, NULL);
    SendMessageW(g_hStatus, WM_SETFONT, (WPARAM)g_font, TRUE);

    g_hTip = CreateWindowExW(0, TOOLTIPS_CLASSW, NULL, WS_POPUP | TTS_ALWAYSTIP | TTS_BALLOON,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
        g_hMain, NULL, inst, NULL);
    if (g_hTip) {
        SendMessageW(g_hTip, TTM_SETDELAYTIME, TTDT_INITIAL, TIP_DELAY_MS);
        SendMessageW(g_hTip, TTM_SETDELAYTIME, TTDT_AUTOPOP, TIP_HIDE_MS);
        SendMessageW(g_hTip, TTM_SETMAXTIPWIDTH, 0, 520);
        TOOLINFOW trackti = { sizeof(trackti) };
        trackti.uFlags = TTF_TRACK | TTF_ABSOLUTE;
        trackti.hwnd = g_hMain;
        trackti.uId = TIP_TRACK_ID;
        trackti.lpszText = (LPWSTR)L"";
        SendMessageW(g_hTip, TTM_ADDTOOLW, 0, (LPARAM)&trackti);

        TOOLINFOW tabti = { sizeof(tabti) };
        tabti.uFlags = TTF_IDISHWND | TTF_SUBCLASS | TTF_TRANSPARENT;
        tabti.hwnd = g_hMain;
        tabti.uId = (UINT_PTR)g_hTab;
        tabti.lpszText = LPSTR_TEXTCALLBACKW;
        SendMessageW(g_hTip, TTM_ADDTOOLW, 0, (LPARAM)&tabti);

        AddToolTip(g_hMin, TR(L"تصغير النافذة (Ctrl+M)", L"Minimize the window (Ctrl+M)"));
        AddToolTip(g_hExit, TR(L"إغلاق البرنامج مع إلغاء أي عملية قيد التشغيل والتفريغ الكامل (Ctrl+Q)",
                               L"Close the program and abort any running operation (Ctrl+Q)"));
        AddToolTip(g_hStatus, TR(L"حالة التشغيل الحالية", L"Current run status"));
    }

    InitTabs();
    ApplyDirection();
    TabCtrl_SetCurSel(g_hTab, g_selTab);
    BuildPage(g_selTab);
    ShowTab(g_selTab);

    ShowWindow(g_hMain, SW_SHOW);
    UpdateWindow(g_hMain);
    RestoreUiState();

    RECT rc;
    GetClientRect(g_hMain, &rc);
    SendMessageW(g_hMain, WM_SIZE, 0, MAKELPARAM(rc.right, rc.bottom));

    if (wcsstr(GetCommandLineW(), L"/selftest")) {
        int g = 0, s = 0;
        const wchar_t* p = wcsstr(GetCommandLineW(), L"/selftest");
        swscanf(p + 9, L" %d %d", &g, &s);
        SelfTest(g, s);
        return 0;
    }

    MSG msg;
    for (;;) {
        HWND f = GetFocus();
        if (f != g_lastFocus) {
            g_lastFocus = f;
            if (f && (f == g_hMain || IsChild(g_hMain, f)))
                ArmTip(f, TipFor(f));
            else
                ArmTip(NULL, std::wstring());
        }
        if (!GetMessageW(&msg, NULL, 0, 0)) break;
        if (msg.message == WM_KEYDOWN && msg.hwnd == g_hTab) {
            if (HandleTabKey((int)msg.wParam)) continue;
        }
        if (msg.message == WM_KEYDOWN && msg.wParam == VK_TAB &&
            (msg.hwnd == g_hMain || IsChild(g_hMain, msg.hwnd))) {
            HWND nx = NextInRing(msg.hwnd, ShiftDown());
            if (nx) SetFocus(nx);
            continue;
        }
        if (msg.message == WM_KEYDOWN && (msg.wParam == VK_APPS || (msg.wParam == VK_F10 && (GetKeyState(VK_SHIFT) & 0x8000))) &&
            (msg.hwnd == g_hMain || IsChild(g_hMain, msg.hwnd))) {
            HWND f = GetFocus();
            if (f) {
                std::wstring t = TipFor(f);
                if (!t.empty()) {
                    // allow re-show: clear shown flag for this control
                    ClearKbTipShown(f);
                    ShowKeyboardTip(f, t);
                    continue;
                }
            }
        }
        if ((msg.message == WM_KEYDOWN || msg.message == WM_SYSKEYDOWN ||
             msg.message == WM_CHAR || msg.message == WM_SYSCHAR) &&
            (msg.hwnd == g_hMain || IsChild(g_hMain, msg.hwnd))) {
            if (IsDialogMessageW(g_hMain, &msg)) continue;
        }
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return 0;
}
