@echo off
rem ============================================================
rem  RepairUI build script
rem  Mingw-w64 (i686) static GUI build.
rem
rem  IMPORTANT: the mingw32 bin directory MUST be on PATH before
rem  calling g++, otherwise cc1plus.exe cannot locate its DLLs and
rem  g++ exits with code 1 WITHOUT printing any error message.
rem ============================================================
setlocal enableextensions

set "MINGW=C:\msys64\mingw32\bin"
set "PATH=%MINGW%;%PATH%"

set "SRC=%~dp0main.cpp"
set "RC=%~dp0app.rc"
set "RES=%~dp0app.res"
set "OUT=%~dp0..\RepairUI.exe"

if not exist "%MINGW%\g++.exe" (
  echo [ERROR] g++ not found at "%MINGW%\g++.exe"
  exit /b 1
)

echo [1/2] Compiling resources ^(windres^)...
"%MINGW%\windres.exe" -i "%RC%" -O coff -o "%RES%"
if errorlevel 1 (
  echo [ERROR] windres failed.
  exit /b 1
)

echo [2/2] Compiling RepairUI.exe ^(g++^)...
"%MINGW%\g++.exe" -municode -finput-charset=UTF-8 -fwide-exec-charset=UTF-16LE ^
  -static -mwindows -Wall "%SRC%" "%RES%" -o "%OUT%" ^
  -lcomctl32 -luser32 -lgdi32 -lshell32 -lcomdlg32 -lkernel32
if errorlevel 1 (
  echo [ERROR] g++ failed ^(exit code %errorlevel%^).
  exit /b 1
)

echo [OK] Build succeeded: "%OUT%"
endlocal
